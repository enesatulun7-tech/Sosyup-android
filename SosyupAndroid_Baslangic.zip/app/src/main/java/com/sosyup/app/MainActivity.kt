package com.sosyup.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF090A10)
private val Panel = Color(0xFF171923)
private val Purple = Color(0xFF8B5CF6)
private val Blue = Color(0xFF398BFF)
private val Muted = Color(0xFF9CA3AF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SosyupApp() }
    }
}

@Composable
fun SosyupApp() {
    var selected by remember { mutableStateOf(0) }
    var showCreate by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Purple,
        secondary = Blue, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            topBar = { SosyupTopBar() },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    val items = listOf(
                        "Ana Sayfa" to Icons.Default.Home,
                        "Keşfet" to Icons.Default.Search,
                        "Ekle" to Icons.Default.AddCircle,
                        "Reels" to Icons.Default.PlayCircle,
                        "Profil" to Icons.Default.Person
                    )
                    items.forEachIndexed { index, item ->
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index; if (index == 2) showCreate = true },
                            icon = { Icon(item.second, contentDescription = item.first) },
                            label = { Text(item.first, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Purple, indicatorColor = Purple.copy(alpha = .18f),
                                unselectedIconColor = Muted, selectedTextColor = Color.White,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when {
                showCreate -> PlaceholderPage("Yeni gönderi", "Fotoğraf veya video paylaşımı için medya yükleme ve izinler eklenecek.", Modifier.padding(padding)) { showCreate = false; selected = 0 }
                selected == 0 -> FeedPage(Modifier.padding(padding))
                selected == 1 -> PlaceholderPage("Keşfet", "Gerçek kullanıcı ve gönderi araması Firebase bağlantısından sonra etkinleşecek.", Modifier.padding(padding))
                selected == 3 -> PlaceholderPage("Reels", "Dikey video akışı ve oynatıcı sonraki geliştirme aşamasında eklenecek.", Modifier.padding(padding))
                else -> PlaceholderPage("Profil", "Ad, kullanıcı adı, biyografi, profil fotoğrafı ve takip bilgileri burada yer alacak.", Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun SosyupTopBar() {
    Row(
        Modifier.fillMaxWidth().background(Ink).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("sosyup", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold,
            color = Color.White)
        Spacer(Modifier.width(4.dp))
        Box(Modifier.size(7.dp).background(Brush.linearGradient(listOf(Purple, Blue)), CircleShape))
        Spacer(Modifier.weight(1f))
        IconButton(onClick = {}) { Icon(Icons.Default.FavoriteBorder, "Bildirimler", tint = Color.White) }
        IconButton(onClick = {}) { Icon(Icons.Default.Send, "Mesajlar", tint = Color.White) }
    }
}

@Composable
fun FeedPage(modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Text("Hikâyeler", color = Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 18.dp, top = 8.dp, bottom = 12.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                StoryBubble("Hikâyen", true)
                StoryBubble("Takip", false)
                StoryBubble("Takip", false)
                StoryBubble("Takip", false)
            }
            Spacer(Modifier.height(18.dp))
            HorizontalDivider(color = Color.White.copy(alpha = .08f))
        }
        item {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("Sosyup'a hoş geldin 💜", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Takip ettiğin kişilerin gönderileri burada görünecek. Henüz gönderi yok.",
                    color = Muted, fontSize = 14.sp)
                Spacer(Modifier.height(16.dp))
                Text("Bu başlangıç ekranında sahte kullanıcı veya örnek gönderi gösterilmez.",
                    color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun StoryBubble(label: String, own: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(64.dp)) {
        Box(Modifier.size(58.dp).background(
            Brush.linearGradient(listOf(Purple, Blue)), CircleShape
        ).padding(3.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) {
            if (own) Icon(Icons.Default.Add, null, tint = Color.White)
            else Icon(Icons.Default.Person, null, tint = Muted)
        }
        Spacer(Modifier.height(5.dp))
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun PlaceholderPage(title: String, detail: String, modifier: Modifier = Modifier, onBack: (() -> Unit)? = null) {
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(detail, color = Muted, fontSize = 14.sp)
        if (onBack != null) {
            Spacer(Modifier.height(18.dp))
            Button(onClick = onBack) { Text("Ana sayfaya dön") }
        }
    }
}
