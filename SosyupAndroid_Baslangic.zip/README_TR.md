# Sosyup Android başlangıç projesi

Bu, Kotlin + Jetpack Compose ile hazırlanmış yerel Android başlangıç iskeletidir.
Sahte kullanıcı veya rastgele gönderi içermez. Şu an Firebase'e bağlı değildir;
giriş, veri okuma/yazma, medya yükleme, mesajlaşma ve bildirimler henüz çalışır
backend özellikleri değildir.

## Derleme
- Android Studio gerekir.
- JDK 17 ve Android SDK 35 gerekir.
- Projeyi Android Studio'da açıp Gradle Sync yapın.
- Build > Build Bundle(s) / APK(s) menüsünden APK veya AAB üretin.

## Firebase sonraki adım
1. Firebase Console'da Android uygulaması oluşturun: `com.sosyup.app`.
2. `google-services.json` dosyasını `app/` klasörüne koyun.
3. Firebase Authentication'da Email/Password sağlayıcısını açın.
4. Firestore Database ve Storage kurun.
5. Güvenlik kurallarını kullanıcı kimliğine göre yapılandırın.

Firebase henüz bağlanmadı. Üretim yayını öncesinde güvenlik kuralları, hesap silme,
gizlilik politikası, izin açıklamaları ve Play Console test gereksinimleri tamamlanmalıdır.
